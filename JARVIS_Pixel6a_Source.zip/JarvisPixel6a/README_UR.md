# JARVIS Personal AI — ابتدائی ورژن

یہ Google Pixel 6a کے لیے ایک ابتدائی Android پروجیکٹ ہے۔ اس میں:
- بٹن دبانے پر اردو آواز کی شناخت
- اردو میں Text-to-Speech جواب (فون کی دستیاب آوازوں پر منحصر)
- YouTube، Wi-Fi settings، Bluetooth settings، Clock، Dialer اور عمومی Settings کھولنے کی بنیادی کمانڈز
- Android mic permission

## ابھی کیا شامل نہیں؟
- مسلسل ہمیشہ سننا
- earbuds کے ساتھ پس منظر میں مستقل گفتگو
- مکمل AI/LLM دماغ یا مستقل یادداشت
- ہر ایپ میں خودکار طور پر بٹن دبانا
- خودکار APK فائل اس ZIP میں تیار نہیں ہے؛ یہ سورس کوڈ ہے

## موبائل سے APK بنانے کا آسان ترین دستیاب راستہ
1. ZIP کو GitHub پر نئی repository میں اپلوڈ کریں، تمام فائلیں extract کرکے repository کی جڑ میں رکھیں۔
2. GitHub میں **Actions** کھولیں اور **Build JARVIS APK** workflow منتخب کریں۔
3. **Run workflow** دبائیں۔
4. مکمل ہونے پر اسی workflow run کے نیچے **Artifacts** میں `jarvis-debug-apk` ڈاؤن لوڈ کریں۔
5. ZIP artifact کو extract کریں؛ `app-debug.apk` فون پر کھول کر انسٹال کریں۔ اگر Android اجازت مانگے تو صرف اس فائل کے لیے اجازت دیں جسے آپ نے خود بنایا ہے۔

## اہم
یہ پروجیکٹ پہلی بار compile کرتے وقت build configuration یا dependency versions کی وجہ سے اصلاح مانگ سکتا ہے۔ Debug APK ٹیسٹنگ کے لیے ہے، Play Store ریلیز کے لیے نہیں۔
