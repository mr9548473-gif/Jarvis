plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.raheel.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.raheel.jarvis"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1"
    }
}
