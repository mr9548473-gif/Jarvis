package com.raheel.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.content.res.ColorStateList
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var listenButton: Button
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "اس فون پر Speech Recognition سروس دستیاب نہیں۔ Google app یا متعلقہ speech service چیک کریں۔"
            listenButton.isEnabled = false
        } else {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "سن رہا ہوں…" }
                override fun onBeginningOfSpeech() { status.text = "آپ کی بات سن رہا ہوں…" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "آپ کی بات سمجھ رہا ہوں…" }
                override fun onError(error: Int) {
                    status.text = "آواز واضح نہیں ہوئی۔ دوبارہ کوشش کریں۔ (کوڈ: $error)"
                    listenButton.isEnabled = true
                }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    transcript.text = "آپ نے کہا: $words"
                    listenButton.isEnabled = true
                    handleCommand(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(12, 17, 28))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(Color.rgb(85, 220, 255))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "السلام علیکم راحیل۔ میں تیار ہوں۔"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 20)
        }
        transcript = TextView(this).apply {
            text = "کمانڈ کی مثالیں:\n• یوٹیوب کھولو\n• وائی فائی سیٹنگز کھولو\n• بلوٹوتھ سیٹنگز کھولو\n• الارم لگانے کی ایپ کھولو\n• ڈائلر کھولو\n• وقت کیا ہوا ہے"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 16, 0, 24)
        }
        listenButton = Button(this).apply {
            text = "🎙️  بات کرنے کے لیے دبائیں"
            textSize = 17f
            setTextColor(Color.BLACK)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(85, 220, 255))
            setOnClickListener { startListening() }
        }
        val note = TextView(this).apply {
            text = "ابتدائی ورژن: بات کرنے کے لیے بٹن دبائیں۔ مسلسل پس منظر میں سننا ابھی شامل نہیں۔"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 28, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(transcript)
        root.addView(listenButton)
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS کو کمانڈ دیں")
        }
        listenButton.isEnabled = false
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            status.text = "مائیکروفون شروع نہیں ہو سکا۔ اجازت اور Speech service چیک کریں۔"
            listenButton.isEnabled = true
        }
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("یوٹیوب") || q.contains("youtube") -> {
                say("یوٹیوب کھول رہا ہوں۔")
                launchPackageOrUrl("com.google.android.youtube", "https://www.youtube.com")
            }
            q.contains("وائی فائی") || q.contains("wifi") -> {
                say("وائی فائی سیٹنگز کھول رہا ہوں۔")
                safelyLaunch(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
            q.contains("بلوٹوتھ") || q.contains("bluetooth") -> {
                say("بلوٹوتھ سیٹنگز کھول رہا ہوں۔")
                safelyLaunch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            }
            q.contains("الارم") || q.contains("alarm") -> {
                say("گھڑی کی ایپ کھول رہا ہوں۔")
                safelyLaunch(Intent( android.provider.AlarmClock.ACTION_SHOW_ALARMS))
            }
            q.contains("ڈائلر") || q.contains("فون کھولو") || q.contains("dialer") -> {
                say("فون ڈائلر کھول رہا ہوں۔")
                safelyLaunch(Intent(Intent.ACTION_DIAL))
            }
            q.contains("وقت") || q.contains("time") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                say("اب وقت ہے $now")
            }
            q.contains("سیٹنگز") || q.contains("settings") -> {
                say("سیٹنگز کھول رہا ہوں۔")
                safelyLaunch(Intent(Settings.ACTION_SETTINGS))
            }
            else -> {
                say("میں نے آپ کی بات سنی، لیکن یہ کمانڈ ابھی میرے پاس موجود نہیں۔ اگلے ورژن میں AI دماغ شامل کیا جا سکتا ہے۔")
                status.text = "کمانڈ سنی گئی، لیکن ابھی سپورٹ نہیں ہوتی۔"
            }
        }
    }

    private fun launchPackageOrUrl(packageName: String, url: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        safelyLaunch(launch ?: Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun safelyLaunch(intent: Intent) {
        try {
            startActivity(intent)
            status.text = "کمانڈ پر عمل کیا گیا۔"
        } catch (e: Exception) {
            status.text = "یہ کام اس وقت نہیں ہو سکا۔"
            say("معاف کیجیے، یہ کام نہیں ہو سکا۔")
        }
    }

    private fun say(message: String) {
        status.text = message
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale("ur", "PK")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 101) {
            status.text = "آواز سننے کے لیے مائیکروفون کی اجازت ضروری ہے۔"
            listenButton.isEnabled = true
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
